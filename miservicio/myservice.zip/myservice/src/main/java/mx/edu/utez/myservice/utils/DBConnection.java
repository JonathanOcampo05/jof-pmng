package mx.edu.utez.myservice.utils;

public class DBConnection {
}
